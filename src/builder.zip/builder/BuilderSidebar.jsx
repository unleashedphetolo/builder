import React, { useEffect, useMemo, useState } from "react";
import "../styles/builderSidebar.css";
import "../styles/panels.css";

import SiteDetailsPanel from "./panels/SiteDetailsPanel";
import SocialPanel from "./panels/SocialPanel";
import AnnouncementsPanel from "./panels/AnnouncementsPanel";
import TemplatePanel from "./panels/TemplatePanel";
import ThemePanel from "./panels/ThemePanel";
import ColorsPanel from "./panels/ColorsPanel";
import PagesPanel from "./panels/PagesPanel";
import SectionsPanel from "./panels/SectionsPanel";
import AnalyticsPanel from "./panels/AnalyticsPanel";

export default function BuilderSidebar({
  siteId,
  layoutKey,
  templateKey,
  templates = [],
  pages = [],
  navItems = [],
  currentPage,
  currentPageData,
  setCurrentPage,
  siteSettings,
  organization,
  onUpdateSettings,
  onUpdateOrganization,
  onUpdateTheme,
  onUpdateColors,
  onUpdateAnnouncements,
  onUpdateSocialMedia,
  onChangeTemplate,
  onUpdatePage,
  onUpdateAnyPage,
  onUpdatePageContent,
  onUpdateAnyPageContent,
  onReorderPages,
  onUpdateTopbar,
  sections = [],
  sectionsLoaded = true,
  selectedSectionId = null,
  onSelectSection,
  onUpdateSectionVisibility,
  onReorderSections,
  onDuplicateSection,
  onDeleteSection,
  onAddSection,
  onRefreshSections,
}) {
  const [activeTab, setActiveTab] = useState("announcements");
  const [hoveredTab, setHoveredTab] = useState("announcements");
  const [openedTab, setOpenedTab] = useState(null);
  const [activeRailItem, setActiveRailItem] = useState("");
  const [sidebarCollapsed, setSidebarCollapsed] = useState(
    typeof window !== "undefined" ? window.innerWidth <= 1024 : false,
  );

  useEffect(() => {
    const collapseSidebarForEditor = (nextActiveRailItem = "") => {
      setOpenedTab(null);
      setSidebarCollapsed(true);

      if (nextActiveRailItem) {
        setActiveRailItem(nextActiveRailItem);
      }
    };

    const handleCloseSidebar = () => {
      collapseSidebarForEditor();
    };

    const handleMediaEditorState = (event) => {
      if (event?.detail?.open === true) {
        collapseSidebarForEditor();
      }
    };

    const handleSectionEditorState = (event) => {
      const detail = event?.detail || {};

      if (detail.open === true) {
        const panelKey = detail.sidebarPanel || "sections";
        setActiveTab(panelKey);
        collapseSidebarForEditor(panelKey);
        return;
      }

      if (detail.open === false) {
        setActiveRailItem("");
      }
    };

    const handleMessage = (event) => {
      const payload = event?.data;

      if (!payload || typeof payload !== "object") return;

      if (payload.type === "builder:close-sidebar") {
        collapseSidebarForEditor();
        return;
      }

      if (
        payload.type === "builder:media-editor-state" &&
        payload.open === true
      ) {
        collapseSidebarForEditor();
        return;
      }

      if (payload.type === "builder:section-editor-state") {
        if (payload.open === true) {
          const panelKey = payload.sidebarPanel || "sections";
          setActiveTab(panelKey);
          collapseSidebarForEditor(panelKey);
          return;
        }

        if (payload.open === false) {
          setActiveRailItem("");
        }
      }
    };

    window.addEventListener("builder:close-sidebar", handleCloseSidebar);
    window.addEventListener(
      "builder:media-editor-state",
      handleMediaEditorState,
    );
    window.addEventListener(
      "builder:section-editor-state",
      handleSectionEditorState,
    );
    window.addEventListener("message", handleMessage);

    return () => {
      window.removeEventListener("builder:close-sidebar", handleCloseSidebar);
      window.removeEventListener(
        "builder:media-editor-state",
        handleMediaEditorState,
      );
      window.removeEventListener(
        "builder:section-editor-state",
        handleSectionEditorState,
      );
      window.removeEventListener("message", handleMessage);
    };
  }, []);

  const tabs = useMemo(
    () => [
      {
        key: "announcements",
        label: "Notices & Updates",
        icon: "📢",
        subtitle: "Manage updates, notices and alerts",
      },
      {
        key: "site",
        label: "Website Details",
        icon: "🏢",
        subtitle: "Identity, logo, contact and branding",
      },
      {
        key: "social",
        label: "Social Media",
        icon: "🔗",
        subtitle: "Topbar, footer and social links",
      },
      {
        key: "templates",
        label: "Website Template",
        icon: "🧩",
        subtitle: "Switch structure for this website category",
      },
      {
        key: "themes",
        label: "Website Themes",
        icon: "🎨",
        subtitle: "Change visual style and theme mode",
      },
      {
        key: "colors",
        label: "Website Colors",
        icon: "🖌️",
        subtitle: "Primary, secondary and background colors",
      },
      {
        key: "pages",
        label: "Pages",
        icon: "📄",
        subtitle: "Control topbar and page visibility.",
      },
      {
        key: "sections",
        label: "Sections",
        icon: "🧱",
        subtitle: "Edit content blocks on the current page",
      },
      {
        key: "analytics",
        label: "Analytics",
        icon: "📊",
        subtitle: "Traffic, trends and performance overview",
      },
    ],
    [],
  );

  const currentTab = useMemo(() => {
    return tabs.find((tab) => tab.key === activeTab) || tabs[0];
  }, [tabs, activeTab]);

  const previewTab = useMemo(() => {
    const keyToUse = openedTab || hoveredTab || activeTab;
    return tabs.find((tab) => tab.key === keyToUse) || tabs[0];
  }, [tabs, openedTab, hoveredTab, activeTab]);

  const closeMediaEditorBeforeOpeningPanel = (tabKey) => {
    const detail = {
      source: "sidebar",
      tabKey,
    };

    /*
    Supports any media editor rendered directly in the builder window.
  */
    window.dispatchEvent(
      new CustomEvent("builder:close-media-editor", {
        detail,
      }),
    );

    /*
    Closes the normal right-side section editor rendered by Builder.jsx.
    A wide left panel and right editor should not occupy the canvas at the
    same time.
  */
    window.dispatchEvent(
      new CustomEvent("builder:close-section-editor", {
        detail,
      }),
    );

    /*
    Closes media and selected-section states running inside the live website
    preview iframe. This keeps template targets visually clean while a left
    panel is being used.
  */
    if (window.previewFrame?.contentWindow) {
      window.previewFrame.contentWindow.postMessage(
        {
          type: "builder:close-media-editor",
          ...detail,
        },
        "*",
      );

      window.previewFrame.contentWindow.postMessage(
        {
          type: "builder:close-section-editor",
          ...detail,
        },
        "*",
      );
    }
  };

  const handleOpenTab = (tabKey) => {
    closeMediaEditorBeforeOpeningPanel(tabKey);

    setSidebarCollapsed(false);
    setActiveTab(tabKey);
    setActiveRailItem(tabKey);
    setOpenedTab(tabKey);
  };

  const handleBack = () => {
    setOpenedTab(null);
  };

  const renderPanelContent = (tabKey) => {
    if (tabKey === "announcements") {
      return (
        <AnnouncementsPanel
          announcements={siteSettings?.announcements || []}
          pages={pages}
          onChange={onUpdateAnnouncements}
        />
      );
    }

    if (tabKey === "site") {
      return (
        <SiteDetailsPanel
          siteSettings={siteSettings}
          organization={organization}
          onUpdateSettings={onUpdateSettings}
          onUpdateOrganization={onUpdateOrganization}
        />
      );
    }

    if (tabKey === "social") {
      return (
        <SocialPanel
          siteSettings={siteSettings}
          onUpdateSocialMedia={onUpdateSocialMedia}
          onUpdateSettings={onUpdateSettings}
        />
      );
    }

    if (tabKey === "templates") {
      return (
        <TemplatePanel
          layoutKey={layoutKey}
          templateKey={templateKey}
          templates={templates}
          onChangeTemplate={onChangeTemplate}
        />
      );
    }

    if (tabKey === "themes") {
      return (
        <ThemePanel
          siteId={siteId}
          layoutKey={layoutKey}
          templateKey={templateKey}
          pages={pages}
          currentPageData={currentPageData}
          siteSettings={siteSettings}
          onUpdateTheme={onUpdateTheme}
          onUpdateSettings={onUpdateSettings}
        />
      );
    }

    if (tabKey === "colors") {
      return (
        <ColorsPanel
          siteSettings={siteSettings}
          onUpdateColors={onUpdateColors}
          onUpdateSettings={onUpdateSettings}
        />
      );
    }

    if (tabKey === "pages") {
      return (
        <PagesPanel
          siteId={siteId}
          layoutKey={layoutKey}
          templateKey={templateKey}
          pages={pages}
          navItems={navItems}
          currentPage={currentPage}
          currentPageData={currentPageData}
          siteSettings={siteSettings}
          setCurrentPage={setCurrentPage}
          onUpdatePage={onUpdatePage}
          onUpdateAnyPage={onUpdateAnyPage}
          onUpdatePageContent={onUpdatePageContent}
          onUpdateAnyPageContent={onUpdateAnyPageContent}
          onReorderPages={onReorderPages}
          onUpdateTopbar={onUpdateTopbar}
        />
      );
    }

    if (tabKey === "sections") {
      return (
        <SectionsPanel
          sections={sections}
          sectionsLoaded={sectionsLoaded}
          selectedSectionId={selectedSectionId}
          currentPageData={currentPageData}
          onSelectSection={onSelectSection}
          onUpdateSectionVisibility={onUpdateSectionVisibility}
          onReorderSections={onReorderSections}
          onDuplicateSection={onDuplicateSection}
          onDeleteSection={onDeleteSection}
          onAddSection={onAddSection}
          onRefresh={onRefreshSections}
        />
      );
    }

    if (tabKey === "analytics") {
      return (
        <AnalyticsPanel
          analytics={siteSettings?.analytics || {}}
          title="Analytics"
        />
      );
    }

    return null;
  };

  const renderPreviewItems = (tabKey) => {
    if (tabKey === "announcements") {
      return (
        <>
          <div className="sidebar-preview-item">Editable notice board</div>
          <div className="sidebar-preview-item">Website updates</div>
          <div className="sidebar-preview-item">Post and manage alerts</div>
        </>
      );
    }

    if (tabKey === "site") {
      return (
        <>
          <div className="sidebar-preview-item">Website name and slogan</div>
          <div className="sidebar-preview-item">Logo and contact details</div>
          <div className="sidebar-preview-item">
            Institution profile settings
          </div>
        </>
      );
    }

    if (tabKey === "social") {
      return (
        <>
          <div className="sidebar-preview-item">Topbar and footer display</div>
          <div className="sidebar-preview-item">
            Platform links and visibility
          </div>
          <div className="sidebar-preview-item">
            Original or mono icon style
          </div>
        </>
      );
    }

    if (tabKey === "templates") {
      return (
        <>
          <div className="sidebar-preview-item">Category-based templates</div>
          <div className="sidebar-preview-item">Switch structure safely</div>
          <div className="sidebar-preview-item">
            Curated institutional layouts
          </div>
        </>
      );
    }

    if (tabKey === "themes") {
      return (
        <>
          <div className="sidebar-preview-item">Planet theme styles</div>
          <div className="sidebar-preview-item">Light and dark mode</div>
          <div className="sidebar-preview-item">Instant visual changes</div>
        </>
      );
    }

    if (tabKey === "colors") {
      return (
        <>
          <div className="sidebar-preview-item">Primary color</div>
          <div className="sidebar-preview-item">Secondary color</div>
          <div className="sidebar-preview-item">Background color</div>
        </>
      );
    }

    if (tabKey === "pages") {
      return (
        <>
          <div className="sidebar-preview-item">Topbar on/off control</div>
          <div className="sidebar-preview-item">Page visibility control</div>
          <div className="sidebar-preview-item">
            Links follow page on/off automatically
          </div>
        </>
      );
    }

    if (tabKey === "sections") {
      return (
        <>
          <div className="sidebar-preview-item">
            Content blocks on this page
          </div>
          <div className="sidebar-preview-item">Show or hide sections</div>
          <div className="sidebar-preview-item">
            Open live right-side section editing
          </div>
        </>
      );
    }

    if (tabKey === "analytics") {
      return (
        <>
          <div className="sidebar-preview-item">Daily to yearly traffic</div>
          <div className="sidebar-preview-item">Performance trends</div>
          <div className="sidebar-preview-item">Growth overview</div>
        </>
      );
    }

    return null;
  };

  return (
    <aside
      className={`sidebar sidebar-shell ${openedTab ? "panel-open" : ""} ${
        sidebarCollapsed ? "sidebar-collapsed" : ""
      }`}
    >
      <div className="sidebar-rail">
        <div className="sidebar-rail-top">
          {tabs.map((tab) => {
            const isActive = activeTab === tab.key;
            const isOpen = openedTab === tab.key;
            const isRailActive = activeRailItem === tab.key;
            const shouldHighlight = activeRailItem
              ? isRailActive || isOpen
              : isActive || isOpen;

            return (
              <button
                key={tab.key}
                type="button"
                className={`sidebar-rail-button ${
                  shouldHighlight ? "active" : ""
                }`}
                onMouseEnter={() => setHoveredTab(tab.key)}
                onFocus={() => setHoveredTab(tab.key)}
                onClick={() => handleOpenTab(tab.key)}
                title={tab.label}
                aria-label={tab.label}
              >
                <span className="sidebar-rail-icon">{tab.icon}</span>
                <span className="sidebar-rail-label">{tab.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {!sidebarCollapsed && !openedTab && (
        <div className="sidebar-preview-panel">
          <div className="sidebar-preview-header">
            <div className="sidebar-preview-header-main">
              <span className="sidebar-preview-icon">{previewTab.icon}</span>
              <div>
                <h3>{previewTab.label}</h3>
                <p>{previewTab.subtitle}</p>
              </div>
            </div>

            <div className="sidebar-preview-actions">
              <button
                type="button"
                className="sidebar-open-button"
                onClick={() => handleOpenTab(previewTab.key)}
              >
                Open
              </button>

              <button
                type="button"
                className="sidebar-preview-close"
                onClick={() => setSidebarCollapsed(true)}
                aria-label="Close preview panel"
                title="Close preview panel"
              >
                ×
              </button>
            </div>
          </div>

          <div className="sidebar-preview-body">
            {renderPreviewItems(previewTab.key)}
          </div>
        </div>
      )}

      {!sidebarCollapsed && openedTab && (
        <div className="sidebar-modal-panel">
          <div className="sidebar-modal-header">
            <button
              type="button"
              className="sidebar-back-button"
              onClick={handleBack}
            >
              ← Back
            </button>

            <div className="sidebar-modal-title-wrap">
              <span className="sidebar-preview-icon">{currentTab.icon}</span>
              <div>
                <h3>{currentTab.label}</h3>
                <p>{currentTab.subtitle}</p>
              </div>
            </div>
          </div>

          <div className="sidebar-content sidebar-modal-content">
            {renderPanelContent(openedTab)}
          </div>
        </div>
      )}
    </aside>
  );
}