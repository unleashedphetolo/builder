import React from "react";
import "../styles/builderSidebar.css";
import "../styles/panels.css";

import SiteDetailsPanel from "./panels/SiteDetailsPanel";
import SocialPanel from "./panels/SocialPanel";
import SeoPanel from "./panels/SeoPanel"; // optional

export default function BuilderSidebar() {
  return (
    <div className="sidebar">
      <div className="sidebar-content">
        {/* 🔥 GLOBAL SITE SETTINGS */}
        <SiteDetailsPanel />

        {/* 🔥 SOCIAL ( TOGGLE SYSTEM) */}
        <SocialPanel />

        {/* 🔥 OPTIONAL SEO */}
        <SeoPanel />
      </div>
    </div>
  );
}