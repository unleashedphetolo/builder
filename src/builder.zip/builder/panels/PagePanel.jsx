import React from "react";
import { useBuilderStore } from "../../store/useBuilderStore";
import "../../styles/panels.css";

export default function PagePanel() {
  const { currentPage, setCurrentPage, sections } = useBuilderStore();

  const pages = [...new Set(sections.map((s) => s.page_id))];

  return (
    <div>
      <h3>Pages</h3>

      {pages.map((page) => (
        // <div
        //   key={page}
        //   className={currentPage === page ? "active-page" : ""}
        //   onClick={() => setCurrentPage(page)}
        // >
        <div
          key={page}
          className={`page-item ${currentPage === page ? "active-page" : ""}`}
          onClick={() => setCurrentPage(page)}
        >
          {page}
        </div>
      ))}
    </div>
  );
}
