import React from "react";
import { useBuilderStore } from "../../store/useBuilderStore";
import "../../styles/panels.css";

export default function SeoPanel() {
  const { siteSettings, setSiteSettings } = useBuilderStore();

  return (
    <div>
      <h3>SEO</h3>

      <label>Meta Title</label>
      <input
        value={siteSettings.meta_title || ""}
        onChange={(e) =>
          setSiteSettings({
            ...siteSettings,
            meta_title: e.target.value,
          })
        }
      />

      <label>Description</label>
      <textarea
        value={siteSettings.meta_description || ""}
        onChange={(e) =>
          setSiteSettings({
            ...siteSettings,
            meta_description: e.target.value,
          })
        }
      />
    </div>
  );
}